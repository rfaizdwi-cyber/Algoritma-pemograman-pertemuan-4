/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(void) {
  int baris, kolom;

  /* Proses pengulangan pertama */
  for (baris = 1; baris <= 1000; baris++) {

    /* Proses pengulangan kedua yang terdapat
     dalam pengulangan pertama */
    for (kolom = 1; kolom <= 10; kolom++) {
      printf("%3d ", baris * kolom);
    }

    printf("\n");
  }

  return 0;
}