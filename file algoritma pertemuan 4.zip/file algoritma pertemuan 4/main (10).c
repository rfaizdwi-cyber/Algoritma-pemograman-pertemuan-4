/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main(void) {
int j;
printf("Statemen sebelum blok pengulangan\n");
j = 10;
while (j < 5) {
printf("Statemen di dalam blok pengulangan\n");
j++;
}
printf("Statemen setelah blok pengulangan\n");
return 0;
}