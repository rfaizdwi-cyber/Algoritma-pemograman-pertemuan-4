/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
  for (int a = 0, b = 0; a < 5; a++, b += 5)
  {
    printf("Baris ke-%d : a = %d, b = %2d\n", a + 1, a, b);
  }

  return 0;
}